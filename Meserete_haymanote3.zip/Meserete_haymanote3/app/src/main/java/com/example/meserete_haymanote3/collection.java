package com.example.meserete_haymanote3;

import java.util.ArrayList;

public interface collection {
    ArrayList<String>collection_val=new ArrayList<>();
    ArrayList<String>collection_val_yeabnete=new ArrayList<>();
}
