package com.example.meserete_haymanote3;

public class yeabnete_course_hoeme {
    public static final  int[] courses_Title_yeabnete={R.string.Tmherete_Haymanote,R.string.Serate_betekerestian,R.string.YmeshafeKeduse_tenate,R.string.Ybetekerstian_tarike,R.string.Sene_Fetret };
    public static  int[] course_detail_yeabnete={R.string.Tmherete_Haymanote_desc,R.string.Serate_betekerestian_desc,R.string.developer_desc,R.string.Sene_Fetret_desc };
    public static int[] images_yeabnete={R.drawable.backgroud_11,R.drawable.background_2,R.drawable.background_3,R.drawable.background_4,R.drawable.background1};
    public static final  int[] courses_pdf_yeabnete={R.string.tmherete_haymanote_pdf,R.string.sereate_betekerstian_pdf,R.string.ymesehafe_keduse_tenate_pdf,R.string.yebetekerstian_tarike_pdf,R.string.sene_fetret_pdf};

}
