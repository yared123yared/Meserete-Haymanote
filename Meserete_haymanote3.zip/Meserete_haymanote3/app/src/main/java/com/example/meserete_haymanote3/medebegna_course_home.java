package com.example.meserete_haymanote3;

import java.util.ArrayList;
import java.util.List;

public class medebegna_course_home {
    public static final  int[] courses_Title={R.string.Tmherete_Haymanote,R.string.Serate_betekerestian,R.string.YmeshafeKeduse_tenate,R.string.Ybetekerstian_tarike,R.string.Sene_Fetret };
    public static  int[] course_detail={R.string.Tmherete_Haymanote_desc,R.string.Serate_betekerestian_desc,R.string.developer_desc,R.string.Sene_Fetret_desc };
    public static int[] images={R.drawable.backgroud_11,R.drawable.background_2,R.drawable.background_3,R.drawable.background_4,R.drawable.background1};
    public static final  int[] courses_pdf={R.string.tmherete_haymanote_pdf,R.string.sereate_betekerstian_pdf,R.string.ymesehafe_keduse_tenate_pdf,R.string.yebetekerstian_tarike_pdf,R.string.sene_fetret_pdf};
//thise will be the resource of exam
public static final  int[] courses_Title_ex={R.string.Tmherete_Haymanote_ex,R.string.Serate_betekerestian_ex,R.string.YmeshafeKeduse_tenate_ex,R.string.Ybetekerstian_tarike_ex,R.string.Sene_Fetret_ex};
    public static  int[] course_detail_ex={R.string.Tmherete_Haymanote_desc_ex,R.string.Serate_betekerestian_desc_ex,R.string.developer_desc_ex,R.string.Sene_Fetret_desc_ex };
    public static int[] images_ex={R.drawable.backgroud_9,R.drawable.background1,R.drawable.background_5,R.drawable.backgroud_6,R.drawable.background1};
    public static final  int[] courses_pdf_ex={R.string.tmherete_haymanote_pdf,R.string.sereate_betekerstian_pdf,R.string.ymesehafe_keduse_tenate_pdf,R.string.yebetekerstian_tarike_pdf,R.string.sene_fetret_pdf};

}
