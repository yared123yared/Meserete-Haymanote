package com.example.meserete_haymanote3;

import java.util.ArrayList;
import java.util.List;

public interface entry_to_app {
    ArrayList<String>initiate_user=new ArrayList<>();
    ArrayList<List>register_user=new ArrayList<>();
    ArrayList<String>current_logged_in_info=new ArrayList<>();
}
